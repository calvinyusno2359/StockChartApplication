# Stock Chart & Moving Average Crossover Application
Stock Chart & Moving Average Crossover Application

## How to Launch the Application
1. Download this repository as `.zip` or (clone it, if you have git)
2. Unzip the `.zip` file if necessary
3. Go to `dist` folder
4. Double click on `app.exe`

## How to Use the Application

## What is this Application?
